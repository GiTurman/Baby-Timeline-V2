
import React, { useState, useEffect, useRef } from 'react';
import { MemoryEntry } from './types';
import MemoryTree from './components/MemoryTree';
import { generateMemoryStory } from './services/geminiService';

const App: React.FC = () => {
  const [memories, setMemories] = useState<MemoryEntry[]>([]);
  const [inputText, setInputText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('kiddo_memories');
    if (saved) {
      setMemories(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('kiddo_memories', JSON.stringify(memories));
  }, [memories]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText && !previewImage) return;

    setIsGenerating(true);
    try {
      const response = await generateMemoryStory(inputText, previewImage || undefined);
      
      const newMemory: MemoryEntry = {
        id: crypto.randomUUID(),
        date: response.suggestedDate || new Date().toISOString().split('T')[0],
        title: response.title || "ახალი თავი",
        originalText: inputText || "ფოტოალბომიდან",
        aiStory: response.story,
        imageUrl: previewImage || undefined,
        timestamp: Date.now()
      };

      setMemories(prev => [newMemory, ...prev]);
      setInputText('');
      setPreviewImage(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err) {
      console.error(err);
      alert("გაუმართაობა ჩაწერისას. სცადეთ მოგვიანებით.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("ნამდვილად გსურთ ამ ჩანაწერის წაშლა წიგნიდან?")) {
      setMemories(prev => prev.filter(m => m.id !== id));
    }
  };

  return (
    <div className="min-h-screen pb-20 bg-[#fdfaf1]">
      <header className="bg-white/90 backdrop-blur-md sticky top-0 z-50 py-6 px-8 shadow-sm flex items-center justify-between border-b-2 border-amber-50">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-rose-400 text-2xl shadow-inner">
            <i className="fa-solid fa-book-open"></i>
          </div>
          <div>
            <h1 className="text-3xl font-serif font-bold text-amber-900 tracking-tight">KIDDO</h1>
            <p className="text-[10px] text-amber-700/60 font-bold uppercase tracking-[0.2em]">ცხოვრების წიგნი</p>
          </div>
        </div>
        <div className="bg-rose-50 px-4 py-1 rounded-full text-xs text-rose-400 font-bold border border-rose-100">
          {memories.length} ფურცელი
        </div>
      </header>

      <main className="container mx-auto max-w-5xl pt-12">
        <div className="px-4 mb-16 text-center">
          <h2 className="text-4xl font-serif font-bold text-amber-900 mb-4">ჩვენი დიდი თავგადასავალი</h2>
          <p className="text-amber-800/60 max-w-xl mx-auto italic font-serif text-lg">
            "ყოველი წამი, როდესაც შენ ჩვენს ცხოვრებაში გაჩნდი, ცალკე ისტორიის ღირსია..."
          </p>
        </div>

        <section className="px-4 mb-24">
          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto bg-white p-10 rounded-xl shadow-xl border border-amber-50 relative">
            <div className="absolute -top-3 -left-3 w-10 h-10 bg-amber-400 rounded-full flex items-center justify-center text-white text-xl shadow-lg">
              <i className="fa-solid fa-pen-nib"></i>
            </div>
            
            <div className="flex flex-col gap-8">
              <div className="space-y-4">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="აღწერე ეს წამი მოკლედ..."
                  className="w-full bg-amber-50/30 rounded-lg p-6 min-h-[120px] border-amber-100 focus:border-rose-300 focus:ring-0 resize-none text-gray-800 text-lg font-serif italic placeholder:text-amber-200"
                />
                
                <div className="flex items-center gap-4">
                  <button 
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-3 px-6 py-3 rounded-full bg-amber-50 text-amber-700 hover:bg-amber-100 transition-all border border-amber-200 font-bold text-xs"
                  >
                    <i className="fa-solid fa-image"></i>
                    ფოტოს დამატება
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleImageChange}
                    accept="image/*"
                    className="hidden"
                  />
                  {previewImage && (
                    <span className="text-xs text-green-600 font-bold flex items-center gap-1">
                      <i className="fa-solid fa-check-circle"></i> ფოტო მზადაა
                    </span>
                  )}
                </div>
              </div>

              {previewImage && (
                <div className="relative w-full h-56 rounded-lg overflow-hidden border-4 border-white shadow-md">
                  <img src={previewImage} alt="Preview" className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => setPreviewImage(null)}
                    className="absolute top-2 right-2 w-8 h-8 bg-rose-500 text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                  >
                    <i className="fa-solid fa-trash-can text-xs"></i>
                  </button>
                </div>
              )}

              <button 
                type="submit"
                disabled={isGenerating || (!inputText && !previewImage)}
                className={`
                  w-full py-5 rounded-lg font-serif font-bold text-xl text-white shadow-xl transition-all
                  ${isGenerating ? 'bg-amber-200 cursor-not-allowed' : 'bg-gradient-to-r from-rose-400 to-amber-500 hover:opacity-90 hover:-translate-y-1 active:scale-95'}
                `}
              >
                {isGenerating ? (
                  <span className="flex items-center justify-center gap-3">
                    <i className="fa-solid fa-feather animate-bounce"></i>
                    ისტორია იწერება...
                  </span>
                ) : (
                  "ჩაწერე წიგნში"
                )}
              </button>
            </div>
          </form>
        </section>

        <section className="mb-20">
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="h-[1px] flex-1 bg-amber-200/50"></div>
            <h3 className="text-3xl font-serif font-bold text-amber-900">დროის ხაზი</h3>
            <div className="h-[1px] flex-1 bg-amber-200/50"></div>
          </div>
          <MemoryTree memories={memories} onDelete={handleDelete} />
        </section>
      </main>

      <footer className="text-center text-amber-800/30 py-16 border-t border-amber-100/50">
        <div className="flex flex-col items-center gap-2">
          <i className="fa-solid fa-leaf text-2xl text-amber-100"></i>
          <p className="font-serif italic">ყოველი მოგონება სათუთად ინახება...</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
