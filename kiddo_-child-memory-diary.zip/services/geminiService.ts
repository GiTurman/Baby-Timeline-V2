
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateMemoryStory(text: string, imageData?: string) {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    შენ ხარ 'მოგონებების ასისტენტი'. შენი მიზანია დაეხმარო მშობელს ორსულობისა და ბავშვის ზრდის დღიურის წარმოებაში.
    
    დავალება:
    მომხმარებლის მოწოდებული მოკლე ფრაზა ან ფოტო გადააქციე ემოციურ, თბილ 'წიგნის გვერდად' ქართულ ენაზე.
    წერა უნდა იყოს პირველ პირში, ნოსტალგიური და ძალიან სიყვარულით სავსე. 
    თუ ფოტოა მოცემული, აღწერე ის ემოციურად და გახადე ისტორიის ნაწილი.
    ისტორია უნდა ჟღერდეს როგორც ნაწყვეტი ძვირფასი საოჯახო წიგნიდან.

    მომხმარებლის შეყვანა: "${text}"
    ${imageData ? "თანდართულია ფოტო." : ""}

    გთხოვთ დააბრუნოთ JSON:
    {
      "story": "ვრცელი, ლიტერატურული და ემოციური ისტორია ქართულად",
      "suggestedDate": "YYYY-MM-DD",
      "title": "მოკლე, პოეტური სათაური ჩანაწერისთვის"
    }
  `;

  const contents: any = { parts: [{ text: prompt }] };
  
  if (imageData) {
    contents.parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: imageData.split(',')[1]
      }
    });
  }

  try {
    const result = await ai.models.generateContent({
      model,
      contents: [contents],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            story: { type: Type.STRING },
            suggestedDate: { type: Type.STRING },
            title: { type: Type.STRING }
          },
          required: ["story", "suggestedDate", "title"]
        }
      }
    });

    return JSON.parse(result.text);
  } catch (error) {
    console.error("AI Generation failed:", error);
    return {
      title: "ლამაზი დღე",
      story: text || "ეს დღე ჩვენს მეხსიერებაში სამუდამოდ დარჩება, როგორც კიდევ ერთი ნაბიჯი დიდ თავგადასავალში...",
      suggestedDate: new Date().toISOString().split('T')[0]
    };
  }
}
