
import React from 'react';
import { MemoryEntry, MemoryGroup } from '../types';
import MemoryCard from './MemoryCard';

interface MemoryTreeProps {
  memories: MemoryEntry[];
  onDelete: (id: string) => void;
}

const MemoryTree: React.FC<MemoryTreeProps> = ({ memories, onDelete }) => {
  // Group and sort memories
  const groups: MemoryGroup[] = React.useMemo(() => {
    const grouped = memories.reduce((acc: { [key: string]: MemoryEntry[] }, memory) => {
      if (!acc[memory.date]) acc[memory.date] = [];
      acc[memory.date].push(memory);
      return acc;
    }, {});

    return Object.entries(grouped)
      .map(([date, items]) => ({
        date,
        memories: items.sort((a, b) => b.timestamp - a.timestamp)
      }))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [memories]);

  if (memories.length === 0) {
    return (
      <div className="text-center py-20 opacity-50">
        <i className="fa-solid fa-seedling text-6xl text-green-300 mb-4"></i>
        <p className="text-xl">ჯერჯერობით მოგონებები არ გაქვს... <br/>დაამატე პირველი ფოტო ან ფრაზა!</p>
      </div>
    );
  }

  return (
    <div className="relative max-w-4xl mx-auto px-4 py-10">
      {/* Central Line */}
      <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-green-100 -translate-x-1/2 z-0 rounded-full hidden md:block"></div>

      <div className="space-y-12">
        {groups.map((group, groupIdx) => (
          <div key={group.date} className="relative z-10">
            {/* Date Badge */}
            <div className="flex justify-center mb-8">
              <span className="bg-green-500 text-white px-6 py-2 rounded-full font-bold shadow-lg">
                {group.date}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {group.memories.map((memory, idx) => (
                <div 
                  key={memory.id} 
                  className={`
                    flex flex-col
                    ${idx % 2 === 0 ? 'md:items-end' : 'md:items-start md:mt-16'}
                  `}
                >
                  <div className="w-full max-w-md">
                    <MemoryCard memory={memory} onDelete={onDelete} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      {/* Roots */}
      <div className="flex justify-center mt-20 opacity-20">
        <i className="fa-solid fa-tree text-9xl text-green-800"></i>
      </div>
    </div>
  );
};

export default MemoryTree;
