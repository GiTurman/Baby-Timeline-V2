
import React from 'react';
import { MemoryEntry } from '../types';

interface MemoryCardProps {
  memory: MemoryEntry;
  onDelete: (id: string) => void;
}

const MemoryCard: React.FC<MemoryCardProps> = ({ memory, onDelete }) => {
  return (
    <div className="relative group p-8 bg-[#fffcf5] border border-amber-100 rounded-lg shadow-md hover:shadow-xl transition-all duration-500 overflow-hidden transform hover:-rotate-1">
      {/* Decorative page corner */}
      <div className="absolute top-0 right-0 w-12 h-12 bg-gradient-to-bl from-amber-100 to-transparent pointer-events-none"></div>
      
      <button 
        onClick={() => onDelete(memory.id)}
        className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity text-amber-300 hover:text-rose-500 z-10"
      >
        <i className="fa-solid fa-feather-pointed"></i> წაშლა
      </button>
      
      <div className="flex flex-col gap-6">
        {memory.imageUrl && (
          <div className="relative">
            <div className="absolute inset-0 bg-amber-900/5 rounded-sm"></div>
            <img 
              src={memory.imageUrl} 
              alt="Memory" 
              className="w-full h-64 object-cover rounded-sm border-8 border-white shadow-sm sepia-[0.2]"
            />
          </div>
        )}
        
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-2xl font-serif text-amber-900 font-bold">{memory.title}</h3>
            <span className="text-sm font-medium text-amber-600/60 font-mono tracking-widest uppercase">
              {memory.date}
            </span>
          </div>
          
          <p className="text-gray-800 leading-relaxed first-letter:text-5xl first-letter:font-serif first-letter:float-left first-letter:mr-3 first-letter:text-rose-400 italic">
            {memory.aiStory}
          </p>
        </div>
      </div>
      
      <div className="mt-8 pt-4 border-t border-amber-50 flex items-center gap-2 text-[10px] text-amber-400 uppercase tracking-tighter italic">
        <i className="fa-solid fa-bookmark text-rose-200"></i>
        <span>ამოკრეფილია მოგონებებიდან: {memory.originalText}</span>
      </div>
    </div>
  );
};

export default MemoryCard;
