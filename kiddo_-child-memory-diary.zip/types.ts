
export interface MemoryEntry {
  id: string;
  date: string;
  title: string;
  originalText: string;
  aiStory: string;
  imageUrl?: string;
  timestamp: number;
}

export interface MemoryGroup {
  date: string;
  memories: MemoryEntry[];
}
